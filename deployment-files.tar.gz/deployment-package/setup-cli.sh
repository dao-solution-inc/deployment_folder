#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}   MyPit CLI Setup${NC}"
echo -e "${BLUE}=====================================${NC}\n"

# Detect OS and architecture
OS="$(uname -s)"
ARCH="$(uname -m)"

if [ "$OS" = "Darwin" ]; then
    if [ "$ARCH" = "arm64" ]; then
        EXECUTABLE="mypit-macos-silicon"
    else
        EXECUTABLE="mypit-macos-intel"
    fi
elif [ "$OS" = "Linux" ]; then
    EXECUTABLE="mypit-linux-x64"
else
    echo -e "${RED}Unsupported OS: $OS${NC}"
    exit 1
fi

echo -e "Detected: ${GREEN}$OS $ARCH${NC}"
echo -e "Using executable: ${GREEN}$EXECUTABLE${NC}\n"

# Check if executable exists
if [ ! -f "$EXECUTABLE" ]; then
    echo -e "${RED}Error: $EXECUTABLE not found!${NC}"
    echo -e "${YELLOW}Please download the correct executable for your platform.${NC}"
    exit 1
fi

# Make executable
chmod +x "$EXECUTABLE"

# Determine installation directory
if [ "$EUID" -eq 0 ] || [ -w "/usr/local/bin" ]; then
    INSTALL_DIR="/usr/local/bin"
else
    INSTALL_DIR="$HOME/.local/bin"
    mkdir -p "$INSTALL_DIR"
fi

echo -e "Installing to: ${GREEN}$INSTALL_DIR${NC}\n"

# Copy executable
cp "$EXECUTABLE" "$INSTALL_DIR/mypit"
chmod +x "$INSTALL_DIR/mypit"

# Check if directory is in PATH
if [[ ":$PATH:" != *":$INSTALL_DIR:"* ]]; then
    echo -e "${YELLOW}⚠️  Warning: $INSTALL_DIR is not in your PATH${NC}"
    echo -e "\nAdd this line to your ~/.bashrc or ~/.zshrc:"
    echo -e "${GREEN}export PATH=\"$INSTALL_DIR:\$PATH\"${NC}\n"
    echo -e "Then run: ${GREEN}source ~/.bashrc${NC} (or ~/.zshrc)\n"
fi

echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}✅ MyPit CLI installed successfully!${NC}"
echo -e "${GREEN}=====================================${NC}\n"
echo -e "You can now use: ${YELLOW}mypit <command>${NC}"
echo -e "\nAvailable commands:"
echo -e "  ${BLUE}mypit install${NC}  - Install and start MyPit"
echo -e "  ${BLUE}mypit stop${NC}     - Stop all services"
echo -e "  ${BLUE}mypit store${NC}    - Backup database"
echo -e "  ${BLUE}mypit restore${NC}  - Restore database"
echo -e "  ${BLUE}mypit clean${NC}    - Remove all data"
echo -e "  ${BLUE}mypit help${NC}     - Show help\n"

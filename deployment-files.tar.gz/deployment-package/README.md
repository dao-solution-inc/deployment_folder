# MyPit Deployment Package

## Quick Start

### Option 1: Using npm CLI (Recommended - Easiest)

1. Install the MyPit CLI globally:
   ```bash
   npm install -g @dao-solution/mypit
   ```

2. Extract the deployment files:
   ```bash
   tar -xzf deployment-files.tar.gz
   cd deployment-package
   ```

3. Run the installation:
   ```bash
   mypit install
   ```

4. Other available commands:
   ```bash
   mypit          # Show help
   mypit stop     # Stop all services
   mypit store    # Backup database
   mypit restore  # Restore from backup
   mypit clean    # Remove all data (use with caution!)
   ```

### Option 2: Using Executable

1. Download the mypit executable for your platform and place it in the deployment-package folder
2. Run the executable:
   - Linux: `./mypit-linux-x64 install`
   - macOS Intel: `./mypit-macos-intel install`
   - macOS Silicon: `./mypit-macos-silicon install`
   - Windows: `mypit-windows-x64.exe install`

   **On macOS, remove quarantine and give execute permissions:**
   ```bash
   chmod +x ./mypit-macos-intel
   xattr -d com.apple.quarantine ./mypit-macos-intel
   # OR for Silicon
   chmod +x ./mypit-macos-silicon
   xattr -d com.apple.quarantine ./mypit-macos-silicon
   ```

### Option 3: Using Bash Script

If npm or executables don't work, use the bash script:
```bash
chmod +x install.sh
./install.sh
```
Or on Windows:
```cmd
install.bat
```

## What the installer does:
- Checks Docker installation
- Starts backend services
- Generates admin and JWT keys
- Configures and starts frontend

## Access MyPit:
  - MyPit Frontend:                 http://localhost:3000
  - Backend Admin Dashboard:        http://localhost:6791
  - MinIO Console:                  http://127.0.0.1:9000
  - API base URL:                   http://127.0.0.1:3211
  - Backend function push endpoint: http://localhost:3210

## Manual Setup

If you prefer manual setup:

1. Start backend:
   ```bash
   cd backend
   docker compose up -d
   ```

2. Start frontend:
   ```bash
   cd frontend
   docker compose up -d
   ```

## Requirements

- Docker Desktop or Docker Engine
- Nodejs 18+ installed
- Ports 3000, 3210, 3211, 6791, 5432, 9000, 9001 available


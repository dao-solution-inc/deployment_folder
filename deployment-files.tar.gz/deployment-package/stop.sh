#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}   Stopping MyPit Services${NC}"
echo -e "${BLUE}=====================================${NC}\n"

# Check if backend folder exists
if [ ! -d "backend" ]; then
    echo -e "${YELLOW}[WARNING] Backend folder not found, skipping...${NC}"
else
    echo -e "Stopping backend services..."
    cd backend
    docker compose down
    if [ $? -ne 0 ]; then
        echo -e "${RED}[ERROR] Failed to stop backend services${NC}"
        exit 1
    fi
    cd ..
    echo -e "${GREEN}[OK] Backend services stopped${NC}\n"
fi

# Check if frontend folder exists
if [ ! -d "frontend" ]; then
    echo -e "${YELLOW}[WARNING] Frontend folder not found, skipping...${NC}"
else
    echo -e "Stopping frontend services..."
    cd frontend
    docker compose down
    if [ $? -ne 0 ]; then
        echo -e "${RED}[ERROR] Failed to stop frontend services${NC}"
        exit 1
    fi
    cd ..
    echo -e "${GREEN}[OK] Frontend services stopped${NC}\n"
fi

echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}   All services stopped successfully!${NC}"
echo -e "${GREEN}=====================================${NC}\n"
echo -e "${YELLOW}Note: Data volumes have been preserved.${NC}"
echo -e "${YELLOW}To remove volumes as well, use:${NC}"
echo "   cd backend && docker compose down -v"
echo "   cd frontend && docker compose down -v"
echo ""

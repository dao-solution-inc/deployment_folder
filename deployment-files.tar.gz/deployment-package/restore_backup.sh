#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}   MyPit Database Restore${NC}"
echo -e "${BLUE}=====================================${NC}\n"

# Check if frontend container is running
if ! docker ps --format '{{.Names}}' | grep -q '^mypit-frontend$'; then
    echo -e "${RED}❌ Frontend container is not running!${NC}"
    echo -e "${YELLOW}💡 Please start the services first using ./install.sh${NC}"
    exit 1
fi

# Check if backup directory exists
BACKUP_DIR="$HOME/Downloads/mypit-backup"
if [ ! -d "$BACKUP_DIR" ]; then
    echo -e "${RED}❌ Backup directory not found at: $BACKUP_DIR${NC}"
    echo -e "${YELLOW}💡 Please run ./store_backup.sh first to create a backup${NC}"
    exit 1
fi

# Find the most recent backup file
echo -e "${BLUE}Looking for backup files...${NC}"
BACKUP_FILE=$(ls -t "$BACKUP_DIR"/mypit-backup-*.tar.gz 2>/dev/null | head -n 1)

if [ -z "$BACKUP_FILE" ]; then
    echo -e "${RED}❌ No backup files found in: $BACKUP_DIR${NC}"
    echo -e "${YELLOW}💡 Please run ./store_backup.sh first to create a backup${NC}"
    exit 1
fi

echo -e "📦 Found backup: ${GREEN}$(basename "$BACKUP_FILE")${NC}\n"
echo -e "${YELLOW}⚠️  WARNING: This will overwrite the current database!${NC}"
read -p "Do you want to continue? (yes/no): " confirm

if [ "$confirm" != "yes" ]; then
    echo -e "${YELLOW}Restore cancelled.${NC}"
    exit 0
fi

# Copy the backup archive from host to container
echo -e "\n${BLUE}Copying backup to container...${NC}"
docker cp "$BACKUP_FILE" mypit-frontend:/tmp/backup.tar.gz

# Extract the backup inside the container
echo -e "${BLUE}Extracting backup...${NC}"
docker exec mypit-frontend tar -xzf /tmp/backup.tar.gz -C /tmp

# Run the import command inside the container
echo -e "${BLUE}Running import...${NC}"
docker exec mypit-frontend npx convex import --replace --yes /tmp/backup.zip

# Cleanup container files
docker exec mypit-frontend rm -rf /tmp/backup.zip /tmp/backup.tar.gz

echo -e "\n${GREEN}=====================================${NC}"
echo -e "${GREEN}✅ Restore completed successfully!${NC}"
echo -e "${GREEN}=====================================${NC}\n"

#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}   MyPit Database Backup${NC}"
echo -e "${BLUE}=====================================${NC}\n"

# Check if frontend container is running
if ! docker ps --format '{{.Names}}' | grep -q '^mypit-frontend$'; then
    echo -e "${RED}❌ Frontend container is not running!${NC}"
    echo -e "${YELLOW}💡 Please start the services first using ./install.sh${NC}"
    exit 1
fi

# Create backup directory if it doesn't exist
BACKUP_DIR="$HOME/Downloads/mypit-backup"
mkdir -p "$BACKUP_DIR"

# Generate timestamp for backup filename
TIMESTAMP=$(date +"%Y%m%d-%H%M%S")
BACKUP_FILE="$BACKUP_DIR/mypit-backup-$TIMESTAMP.tar.gz"

echo -e "📦 Exporting database to: ${GREEN}$BACKUP_FILE${NC}\n"

# Cleanup any existing backup files from previous runs
docker exec mypit-frontend rm -rf /tmp/backup.zip /tmp/backup.tar.gz 2>/dev/null || true

# Run the export command inside the container
echo -e "${BLUE}Running export...${NC}"
docker exec mypit-frontend npx convex export --include-file-storage --path /tmp/backup.zip

# Create tar.gz file inside the container
echo -e "${BLUE}Creating backup archive...${NC}"
docker exec mypit-frontend tar -czf /tmp/backup.tar.gz -C /tmp backup.zip

# Copy the backup archive from container to host
echo -e "${BLUE}Copying backup to local machine...${NC}"
docker cp mypit-frontend:/tmp/backup.tar.gz "$BACKUP_FILE"

# Cleanup container backup files
docker exec mypit-frontend rm -rf /tmp/backup.zip /tmp/backup.tar.gz

echo -e "\n${GREEN}=====================================${NC}"
echo -e "${GREEN}✅ Backup completed successfully!${NC}"
echo -e "${GREEN}=====================================${NC}\n"
echo -e "📁 Backup saved to: ${YELLOW}$BACKUP_FILE${NC}\n"

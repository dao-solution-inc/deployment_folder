#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 Starting MyPit Installation${NC}\n"

# Step 0: Check required folders exist
echo -e "0️⃣  Checking installation files..."
if [ ! -d "backend" ] || [ ! -d "frontend" ]; then
    echo -e "\n${RED}❌ Installation files not found!${NC}"
    echo -e "\n${YELLOW}📦 Please make sure you have:${NC}"
    echo "   1. Downloaded deployment-files.tar.gz from the GitHub release"
    echo "   2. Extracted it: tar -xzf deployment-files.tar.gz"
    echo "   3. Run this script from inside the deployment-package folder"
    echo ""
    echo -e "${YELLOW}💡 Your folder structure should look like:${NC}"
    echo "   deployment-package/"
    echo "   ├── backend/"
    echo "   │   ├── docker-compose.yml"
    echo "   │   └── .env"
    echo "   ├── frontend/"
    echo "   │   ├── docker-compose.yml"
    echo "   │   └── .env"
    echo "   ├── README.md"
    echo "   └── install.sh (this script)"
    echo ""
    exit 1
fi
echo -e "${GREEN}✅ Installation files found${NC}\n"

# Step 1: Check Docker
echo -e "1️⃣  Checking Docker installation..."
if ! command -v docker &> /dev/null; then
    echo -e "\n${RED}❌ Docker is not installed or not in PATH!${NC}"
    echo -e "${YELLOW}📦 Please install Docker Desktop from: https://www.docker.com/products/docker-desktop${NC}"
    echo "   - For macOS: https://docs.docker.com/desktop/install/mac-install/"
    echo "   - For Linux: https://docs.docker.com/desktop/install/linux-install/"
    echo ""
    echo -e "${YELLOW}💡 After installing Docker, make sure it's running and try again.${NC}"
    exit 1
fi

if ! docker info &> /dev/null; then
    echo -e "\n${RED}❌ Docker is not running!${NC}"
    echo -e "${YELLOW}💡 Please start Docker Desktop and try again.${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Docker is installed and running${NC}\n"

# Step 2: Start backend
echo -e "2️⃣  Starting backend services..."
cd backend
docker compose up -d
cd ..
echo -e "${GREEN}✅ Backend services started${NC}\n"

# Wait for backend to be ready
echo -e "\n⏳ Waiting for backend to be ready..."
for i in {1..30}; do
    if docker compose -f backend/docker-compose.yml exec -T backend curl -f http://localhost:3210/version &> /dev/null; then
        echo -e "${GREEN}✅ Backend is ready!${NC}"
        break
    fi
    if [ $i -eq 30 ]; then
        echo -e "\n${RED}❌ Backend failed to become ready${NC}"
        exit 1
    fi
    echo -n "."
    sleep 2
done

# Step 3: Generate admin key
echo -e "\n3️⃣  Generating admin key..."
ADMIN_KEY=$(docker compose -f backend/docker-compose.yml exec -T backend ./generate_admin_key.sh | grep -v "^\s*$" | tail -n 1 | tr -d '\r\n')
echo -e "${GREEN}✅ Admin key generated${NC}"

# Step 4: Create frontend/.env with admin key and configuration
echo -e "\n4️⃣  Creating frontend/.env with configuration..."
# Delete existing .env file
if [ -f "frontend/.env" ]; then
    rm -f frontend/.env
fi
# Create new .env file with all required variables
cat > frontend/.env << EOF
CONVEX_SELF_HOSTED_ADMIN_KEY=${ADMIN_KEY}
NEXT_PUBLIC_CONVEX_URL=http://127.0.0.1:3210
CONVEX_SELF_HOSTED_URL=http://backend-backend-1:3210
EOF
echo -e "Created .env with:"
echo -e "  CONVEX_SELF_HOSTED_ADMIN_KEY=${ADMIN_KEY}"
echo -e "  NEXT_PUBLIC_CONVEX_URL=http://127.0.0.1:3210"
echo -e "  CONVEX_SELF_HOSTED_URL=http://backend-backend-1:3210"
echo -e "${GREEN}✅ Frontend .env created${NC}\n"

# Step 5: Build frontend container
echo -e "5️⃣  Building frontend container..."
cd frontend
docker compose build
cd ..
echo -e "${GREEN}✅ Frontend container built${NC}\n"

# Step 6: Start frontend container (temporary mode) to generate keys
echo -e "6️⃣  Starting frontend container (temporary mode)..."
cd frontend
docker compose run -d --name mypit-frontend-temp --service-ports frontend tail -f /dev/null
cd ..
echo -e "${GREEN}✅ Frontend container started${NC}\n"

# Step 7: Generate JWT keys inside the container
echo -e "7️⃣  Generating JWT keys inside container..."

KEYS_OUTPUT=$(docker exec mypit-frontend-temp node generateKeys.mjs 2>&1)
JWT_PRIVATE_KEY=$(echo "$KEYS_OUTPUT" | grep "JWT_PRIVATE_KEY=" | sed 's/JWT_PRIVATE_KEY="\(.*\)"/\1/')
JWKS=$(echo "$KEYS_OUTPUT" | grep "JWKS=" | sed 's/JWKS=//')

if [ -z "$JWT_PRIVATE_KEY" ] || [ -z "$JWKS" ]; then
    echo -e "\n${RED}❌ Failed to generate JWT keys${NC}"
    echo "$KEYS_OUTPUT"
    exit 1
fi

echo -e "${GREEN}✅ JWT keys generated${NC}\n"

# Step 8: Set Convex environment variables inside the container
echo -e "8️⃣  Setting Convex environment variables inside container..."

echo "   Setting JWKS..."
docker exec mypit-frontend-temp npx convex env set "JWKS=${JWKS}"

echo "   Setting JWT_PRIVATE_KEY..."
docker exec mypit-frontend-temp npx convex env set "JWT_PRIVATE_KEY=${JWT_PRIVATE_KEY}"

echo "   Setting PRIVATE_KEY..."
docker exec mypit-frontend-temp npx convex env set "PRIVATE_KEY=$(date +%s)"

echo "   Setting SITE_URL..."
docker exec mypit-frontend-temp npx convex env set "SITE_URL=http://localhost:3000"

echo -e "${GREEN}✅ Convex environment variables set${NC}\n"

# Step 9: Deploy Convex functions and schema inside the container
echo -e "9️⃣  Deploying Convex functions and schema inside container..."
docker exec mypit-frontend-temp npx convex deploy --yes
echo -e "${GREEN}✅ Convex functions deployed${NC}\n"

# Step 10: Stop temporary container and start with proper command
echo -e "🔟 Restarting frontend with proper configuration..."
docker stop mypit-frontend-temp
docker rm mypit-frontend-temp
cd frontend
docker compose up -d
cd ..
echo -e "${GREEN}✅ Frontend service started${NC}\n"

# Done
echo -e "${GREEN}🎉 Installation completed successfully!${NC}\n"
echo -e "${BLUE}📍 Services are running at:${NC}"
echo -e "${GREEN}🌐 MYPIT Frontend running on:   http://127.0.0.1:3000${NC}"
echo -e "${GREEN}📊 Backend Admin Dashboard:     http://127.0.0.1:6791${NC}"
echo -e "${GREEN}MinIO Console:                  http://127.0.0.1:9000${NC}"
echo -e "${GREEN}API base URL:                   http://127.0.0.1:3211${NC}"
echo -e "${GREEN}🔧 Backend functions push:       http://127.0.0.1:3210${NC}"

echo -e "\n${YELLOW}💡 To stop services:${NC}"
echo "   chmod +x stop.sh && ./stop.sh"
